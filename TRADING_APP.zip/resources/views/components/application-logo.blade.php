<img src="{{ asset('assets/core/logo.png') }}" alt="" width="200px">
