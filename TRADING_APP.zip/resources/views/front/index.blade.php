@extends('front.layouts.master')
@section('title', 'Home')
@section('content')
    
@endsection