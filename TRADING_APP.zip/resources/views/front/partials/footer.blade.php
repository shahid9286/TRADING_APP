<footer class="footer brand-1 mt-2">
    <div class="container">
      <div class="footer__wrapper">
        
        <div class="footer__bottom">
          <div class="footer__end">
            <div class="footer__end-copyright">
              <p class=" mb-0">© {{ now()->year}} Rights Reserved By <a href="/" >Trade Pluss</a> </p>
            </div>
            <div>
              <ul class="social">
                <li class="social__item"> <a href="{{ route('front.about')}}">About Us</a> </li>
                <li class="social__item"> <a href="{{ route('front.contact')}}">Contact Us</a> </li>
                <li class="social__item"> <a href="{{ route('front.privacy.policy')}}">Privacy Policy</a> </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>