<link rel="shortcut icon" href="{{ asset($setting->fav_icon) }}" type="image/x-icon">

<link rel="stylesheet" href="{{ asset('front/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('front/css/aos.css') }}">
<link rel="stylesheet" href="{{ asset('front/css/all.min.css') }}">

<link rel="stylesheet" href="{{ asset('front/css/swiper-bundle.min.css') }}">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<!-- main css for template -->
<link rel="stylesheet" href="{{ asset('front/css/style.css') }}">
