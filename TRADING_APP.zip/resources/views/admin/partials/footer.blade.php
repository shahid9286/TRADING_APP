<footer class="main-footer">
  <div class="d-inline">All rights are reserved</div>
  <div class="float-right d-none d-sm-inline-block">
    <a href="https://aimgetsolution.com/" target="_blank">AimGetSolution</a> - Copyright &copy; {{ config('app.name', 'Tahzeel') }} {{ date('Y') }}
  </div>
</footer>
</div>